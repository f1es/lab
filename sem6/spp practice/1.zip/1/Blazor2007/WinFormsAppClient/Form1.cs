namespace WinFormsAppClient
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			pictureBox1.ImageLocation = "https://localhost:7039/Image";
		}
	}
}